defmodule NftVwrWeb.PageViewTest do
  use NftVwrWeb.ConnCase, async: true
end
