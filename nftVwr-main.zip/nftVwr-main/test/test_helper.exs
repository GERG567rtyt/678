ExUnit.start()
Ecto.Adapters.SQL.Sandbox.mode(NftVwr.Repo, :manual)
