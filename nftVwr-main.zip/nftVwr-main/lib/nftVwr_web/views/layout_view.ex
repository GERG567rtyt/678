defmodule NftVwrWeb.LayoutView do
  use NftVwrWeb, :view


end
