defmodule NftVwrWeb.PageView do
  use NftVwrWeb, :view
end
